﻿using ContactsBookApp.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Bogus;

namespace ContactsBookApp.Services
{
    public class ContactsService
    {
        public IEnumerable<Contact> GetContacts()
        {
            var faker = new Faker();
            var list =  new List<Contact>()
            {
                new Contact()
                {
                    FirstName = "John",
                    LastName = "Doe",
                    Email = "john.doe@gmail.com"
                }
            };
            for(int i = 0; i < 10; i++)
            {
                list.Add(new Contact()
                {
                    FirstName = faker.Name.FirstName(),
                    LastName = faker.Name.LastName(),
                    Email = faker.Internet.Email()
                });
            }
            return list;
        }
    }
}
