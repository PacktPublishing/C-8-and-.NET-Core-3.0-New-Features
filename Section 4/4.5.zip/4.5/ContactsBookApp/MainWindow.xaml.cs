﻿using ContactsBookApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ContactsBookApp.Services;
using System.Collections.ObjectModel;

namespace ContactsBookApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Contact> Contacts = new ObservableCollection<Contact>();

        public Contact Contact = new Contact()
        {
            FirstName = "",
            LastName = "",
            Email = "",
            Phone = ""
        };
        public MainWindow()
        {
            InitializeComponent();
            ContactsService service = new ContactsService();
            var contacts = service.GetContacts();
            foreach(var contact in contacts)
            {
                Contacts.Add(contact);
            }
            ContactsBox.ItemsSource = Contacts;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Contact = new Contact();
            Contact.FirstName = FirstNameBox.Text;
            Contact.LastName = LastNameBox.Text;
            Contact.Email = EmailAddressBox.Text;
            Contact.Phone = PhoneNumberBox.Text;
            Contacts.Add(Contact);
            FirstNameBox.Clear();
            LastNameBox.Clear();
            EmailAddressBox.Clear();
            PhoneNumberBox.Clear();
        }
    }
}
