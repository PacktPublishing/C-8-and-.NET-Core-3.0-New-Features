﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Section3Video2.Exceptions
{
    public class HttpException : Exception
    {
        public string Url { get; }
        public int StatusCode { get; }
        public HttpException(string message, string url, int statusCode) : base(message)
        {
            Url = url;
            StatusCode = statusCode;
        }
    }
}
