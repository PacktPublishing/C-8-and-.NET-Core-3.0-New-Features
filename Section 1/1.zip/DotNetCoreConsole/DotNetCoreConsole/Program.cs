﻿using System;

namespace DotNetCoreConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            string msg = "Hello World";
            Console.WriteLine(msg);
            Console.ReadKey();
        }
    }
}
