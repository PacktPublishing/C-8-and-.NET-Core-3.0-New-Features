﻿using System;

namespace Section2Video2
{
    class Student
    {
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string? Email { get; set; }
        public string? Gpa { get; set; }

    }

    class Program
    {
        static void Main(string[] args)
        {
            var student = new Student()
            {
                FirstName = "John",
                //LastName = "Doe"
            };

            Console.WriteLine($"The student is called {student.FirstName} {student.LastName.ToUpper()}");
            Console.ReadKey();
        }
    }
}
