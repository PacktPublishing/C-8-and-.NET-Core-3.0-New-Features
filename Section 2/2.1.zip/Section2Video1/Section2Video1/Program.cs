﻿using System;

namespace Section2Video1
{
    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public double Gpa { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Student s = null;
            Console.WriteLine($"Student {s.FirstName} {s.LastName} has a GPA of {s.Gpa}");
        }
    }
}











